#!/bin/bash

echo "Enter Path To Backup:"
read path
echo "Enter Backup Directory:"
read path_backup_directory

if [ -d "$path" ]
then
    date=$(date +"%y"-"%m"-"%d")
    tar -czf "$path_backup_directory"/backup_"$date".tar.gz "$path"
    echo "Backup Created Successfully"
else
    echo "Directory Not Found"
    exit
fi